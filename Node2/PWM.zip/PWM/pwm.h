#include "stdint.h"

void set_duty_cycle_CH1(uint32_t promille);
void init_pwm();