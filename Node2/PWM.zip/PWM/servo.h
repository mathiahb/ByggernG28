#include "stdint.h"


void joystick_set_servo_position(int32_t joystick_position);
void init_servo();