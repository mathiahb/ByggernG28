#include "adc.h"

#include "../sam/sam3x/include/sam.h"

void init_ADC(){

    REG_ADC_WPMR = (0x414443 << ADC_WPMR_WPKEY_Pos);

    

    REG_ADC_EMR = ADC_EMR_CMPMODE_LOW | ADC_EMR_CMPSEL(10);
    REG_ADC_CWR = ADC_CWR_LOWTHRES(100);

    REG_ADC_IER = ADC_IER_EOC10 | ADC_IER_COMPE;

    
    REG_ADC_WPMR = ADC_WPMR_WPEN | (0x414443 << ADC_WPMR_WPKEY_Pos);
}