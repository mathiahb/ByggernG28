
void init_ADC();